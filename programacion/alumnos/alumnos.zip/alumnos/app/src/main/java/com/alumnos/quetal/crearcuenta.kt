package com.alumnos.quetal

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.navigation.fragment.findNavController
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.crearcuenta.*

/**
 * A simple [Fragment] subclass as the second destination in the navigation.
 */
class crearcuenta : Fragment() {

    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.crearcuenta, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<Button>(R.id.button_second).setOnClickListener {
            findNavController().navigate(R.id.action_SecondFragment_to_FirstFragment)
        }
        setup()
    }
    private fun setup() {

        button2.setOnClickListener {
            if (editTextTextPassword2.text.toString()!=editTextTextPassword3.text.toString()){
                login()
            }

            if (editTextTextEmailAddress.text.isNotEmpty() && editTextTextPassword2.text.isNotEmpty() && editTextTextPassword3.text.toString()==editTextTextPassword2.text.toString()) {

                FirebaseAuth.getInstance()
                    .createUserWithEmailAndPassword(
                        editTextTextEmailAddress.text.toString(),
                        editTextTextPassword2.text.toString()
                    ).addOnCompleteListener {
                        if (it.isSuccessful) {
                            showHome()

                        } else {
                            showAlert()
                        }
                    }

            }
        }
    }

    private fun showAlert() {
        val builder = AlertDialog.Builder(context)
        builder.setTitle("Error")
        builder.setMessage("Hubo un error :( ¡La cuenta de mail deve ser valida y la clave deve tener almenos 6 digitos!")
        builder.setPositiveButton("Aceptar",null)
        val dialog: AlertDialog = builder.create()
        dialog.show()}
    private fun login() {
        val correcto = AlertDialog.Builder(context)
        correcto.setTitle("Error")
        correcto.setMessage("Hubo un error :( ¡Las contraseñas no coinsiden entre si!")
        correcto.setPositiveButton("Aceptar",null)
        val noSe: AlertDialog = correcto.create()
        noSe.show()}
    enum class providerTipe {
        BASIC }
    private fun showHome() {
        val hola: Intent = Intent(context, logute::class.java)
        startActivity(hola)
    }
}